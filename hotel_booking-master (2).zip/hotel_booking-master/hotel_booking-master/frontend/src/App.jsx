import "./App.css";

function App() {
  return (
    <>
      <h1>Hotel Booking Project</h1>
    </>
  );
}

export default App;
