package com.mansoor.hotelbooking.repository;

public class BookedRoomRepository {
}
