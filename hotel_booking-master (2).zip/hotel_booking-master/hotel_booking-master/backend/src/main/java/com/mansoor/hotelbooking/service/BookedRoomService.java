package com.mansoor.hotelbooking.service;

public interface BookedRoomService {
}
