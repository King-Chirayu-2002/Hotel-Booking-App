package com.mansoor.hotelbooking.controller;

public class BookedRoomController {
}
