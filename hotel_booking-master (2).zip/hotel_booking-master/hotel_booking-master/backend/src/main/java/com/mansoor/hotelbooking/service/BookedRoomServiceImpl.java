package com.mansoor.hotelbooking.service;

public class BookedRoomServiceImpl {
}
